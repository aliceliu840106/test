
import requests
import sys

#token="TzEm1zHqVydEeVsGv5Fy"
url="http://gitlab.tool.tsmc-devops-demo.ga/api/v4/"
parent_id="5"
token=sys.argv[1]
group_name=sys.argv[2]
project_name=sys.argv[3]
tag_name=sys.argv[4]

def create_group(session, url, token, group_name):
    response=session.post(url+"groups?path="+group_name+"&name="+group_name+"&parent_id="+parent_id,headers={'PRIVATE-TOKEN': token})
    if (response.status_code==400 and "has already been taken" in response.json()['message']):
        response=session.get(url+"groups?search="+group_name,headers={'PRIVATE-TOKEN': token})
        print(response.json())
        return response.json()[0]['id']
    elif (response.status_code>=200 and response.status_code<300 ):
        print(response.json())
        return response.json()['id']
    else:
        print(response.json())
        return -1

def create_project(session, url, token, project_name,group_id):
    response=session.post(url+"projects?name="+project_name+"&namespace_id="+group_id,headers={'PRIVATE-TOKEN': token})
    print(response.status_code)
    if (response.status_code==400 and "has already been taken" in str(response.json()['message'])):
        response=session.get(url+"projects?search="+project_name,headers={'PRIVATE-TOKEN': token})
        print(response.json())
        return response.json()[0]['http_url_to_repo']
    elif (response.status_code>=200 and response.status_code<300):
        print(response.json())
        return response.json()['http_url_to_repo']
    else:
        print(response.json())
        return -1
if __name__ == '__main__':
    session=requests.session()
    group_id=str(create_group(session, url, token, group_name))
    if(group_id=='-1'):
        sys.exit()
    else:    
        print(group_id)
        print(project_name)
        project_url=str(create_project(session, url, token, project_name, group_id))
        print(project_url)
        if (project_url==-1 ):
           sys.exit() 
        else:
            fp = open("git.txt", "w")
            fp.write(project_url)
            fp.close()

