import os
import sys
import pandas as pd
import json

file_list=[]
for file in [doc for doc in os.listdir(sys.argv[1])
if doc.endswith(".json")]:

	file_list.append(file)

total_df=pd.DataFrame()
for item in file_list:
	print(sys.argv[1]+"/"+item)

	with open(sys.argv[1]+"/"+item, 'r') as f:
		data = json.load(f)
	df = pd.DataFrame(data["vulnerabilities"])
	total_df=total_df.append(pd.json_normalize(data["vulnerabilities"]),ignore_index=True)
	print(df) 
print(total_df)
if (total_df.empty):
	result={"Critical":0,"High":0,"Medium":0,"Low":0,"Info":0}
	total_df.to_csv('SAST-scan-result.csv') 
else:
	result=total_df['severity'].value_counts().to_dict()
	print(result)
	final_result=["Critical","High","Medium","Low","Info"]
	for item in final_result:
		if item not in result:
			result[item]=0

	print(result)
	total_df.to_csv('SAST-scan-result.csv')  
#print(total_df.iloc[0])


print(result["Critical"])
value = str(result["Critical"])
#s.system("export Critical="{value}"")

with open('SAST-scan-result.json', 'w') as fp:
    json.dump(result, fp)

	 


